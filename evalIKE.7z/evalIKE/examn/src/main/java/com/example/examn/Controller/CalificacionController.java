package com.example.examn.Controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.examn.dto.CalificacionDto;
import com.example.examn.repository.CalificacionRepository;

import com.example.examn.service.CalificacionService;

@RestController
@RequestMapping("api")
public class CalificacionController {
	@Autowired
	CalificacionService calificacionService;
	CalificacionRepository calificacionRepository;
	@RequestMapping("/listar")
	public List<CalificacionDto>  obtenerTodo() {
		return calificacionService.obtenerTodo();
	}
	
	@PostMapping("/Post")
	public CalificacionDto insertCalificacion(@RequestBody CalificacionDto calificacionDto) {
		return calificacionService.insertCalificacion(calificacionDto);
	}
	
	@PutMapping("/Put")
	public CalificacionDto modificarCalificacion(@RequestBody CalificacionDto calificacionDto) {
		return calificacionService.insertCalificacion(calificacionDto);
	}
	
	@DeleteMapping("/delete/{pkId}")
	public CalificacionDto deleteTipoRespuesto(@PathVariable("pkId") Integer pkId ) {
		return calificacionService.deleteById(pkId);
	}
	

}
