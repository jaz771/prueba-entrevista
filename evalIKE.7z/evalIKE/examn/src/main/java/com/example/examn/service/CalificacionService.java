package com.example.examn.service;

import java.util.List;

import org.springframework.web.bind.annotation.RequestBody;

import com.example.examn.dto.CalificacionDto;


public interface CalificacionService {
	List<CalificacionDto> obtenerTodo();
	
	CalificacionDto insertCalificacion(@RequestBody CalificacionDto calificacionDto);
	
	CalificacionDto modificarCalificacion(@RequestBody CalificacionDto calificacionDto);
	
	CalificacionDto deleteById(Integer pkId);
}
