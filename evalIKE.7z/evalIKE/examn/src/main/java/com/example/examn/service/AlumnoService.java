package com.example.examn.service;

import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.examn.dto.AlumnoDto;
import com.example.examn.modelo.Alumno;

public interface AlumnoService {
	
	List<AlumnoDto> traeTodo();
	
	AlumnoDto insertAlumno(@RequestBody  AlumnoDto alumnoDto);

	
	

}
