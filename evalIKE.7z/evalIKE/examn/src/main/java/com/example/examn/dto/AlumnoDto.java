package com.example.examn.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class AlumnoDto {
 
	private int pkId;
	private String nombre;
	private String apellido_p;
	private String apellido_m;
	private String materia;
	
	
	

	@Override
	public String toString() {
		return "AlumnoDTO [pkId=" + pkId + ", nombre=" + nombre + ", apellido_p=" + apellido_p + ", apellido_m="
				+ apellido_m + ", materia=" + materia + "]";
	}
	public int getPkId() {
		return pkId;
	}
	public void setPkId(int pkId) {
		this.pkId = pkId;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellido_p() {
		return apellido_p;
	}
	public void setApellido_p(String apellido_p) {
		this.apellido_p = apellido_p;
	}
	public String getApellido_m() {
		return apellido_m;
	}
	public void setApellido_m(String apellido_m) {
		this.apellido_m = apellido_m;
	}
	public String getMateria() {
		return materia;
	}
	public void setMateria(String materia) {
		this.materia = materia;
	}
	

}
