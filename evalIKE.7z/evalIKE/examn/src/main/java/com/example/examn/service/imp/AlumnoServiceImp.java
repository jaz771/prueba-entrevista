package com.example.examn.service.imp;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.examn.dto.AlumnoDto;
import com.example.examn.modelo.Alumno;

import com.example.examn.repository.AlumnoRepository;

import com.example.examn.service.AlumnoService;
@Service
public class AlumnoServiceImp implements AlumnoService {
@Autowired
AlumnoRepository alumnoRepository;

@Override

public List <AlumnoDto> traeTodo(){
	List<AlumnoDto> dtoList=new ArrayList<AlumnoDto>();
	
	try {
		List<Alumno> alumnos=alumnoRepository.findAll();
		for(Alumno alumno: alumnos) {
			AlumnoDto dto= new AlumnoDto();
			dto.setPkId(alumno.getPkId());
			dto.setNombre(alumno.getNombre());
			dto.setApellido_p(alumno.getApellido_p());
			dto.setApellido_m(alumno.getApellido_m());
			dtoList.add(dto);
		}
		
	}catch(Exception e) {
		e.printStackTrace();
	}
	return dtoList;
	
	
	
	
}

@Override
public AlumnoDto insertAlumno(AlumnoDto alumnoDto) {
	try {
		
	
		
		Alumno alumno =new Alumno();		
		alumno.setNombre(alumnoDto.getNombre());
		alumno.setApellido_p(alumnoDto.getApellido_p());
		alumno.setApellido_m(alumnoDto.getApellido_m());
		
		alumnoRepository.save(alumno);
	} catch (Exception e) {
		
	}
	return alumnoDto;
}




}
