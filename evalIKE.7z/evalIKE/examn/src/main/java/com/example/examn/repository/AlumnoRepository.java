package com.example.examn.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.examn.modelo.Alumno;


@Repository

public interface AlumnoRepository extends JpaRepository<Alumno, Integer> {
		

}
