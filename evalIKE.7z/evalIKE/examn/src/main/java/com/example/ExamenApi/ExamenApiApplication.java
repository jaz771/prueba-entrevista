package com.example.ExamenApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamenApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExamenApiApplication.class, args);
	}

}
