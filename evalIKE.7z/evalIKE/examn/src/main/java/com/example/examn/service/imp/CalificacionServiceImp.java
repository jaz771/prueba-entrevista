package com.example.examn.service.imp;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.examn.dto.CalificacionDto;
import com.example.examn.modelo.Alumno;
import com.example.examn.modelo.Calificacion;
import com.example.examn.modelo.Materia;
import com.example.examn.repository.CalificacionRepository;

import com.example.examn.service.CalificacionService;

@Service
public class CalificacionServiceImp implements CalificacionService {
@Autowired
CalificacionRepository calificacionRepository;

@Override
public List<CalificacionDto> obtenerTodo(){
	
	List<CalificacionDto> dtoLista=new ArrayList<CalificacionDto>();
	
	try {
		List<Calificacion> calificaciones=calificacionRepository.findAll();
		for(Calificacion calificacion: calificaciones) {
			CalificacionDto dto =new CalificacionDto();
			dto.setPkId(calificacion.getPkId());
			dto.setPkIdmateria(calificacion.getPkIdmateria());
			dto.setCalificacion(calificacion.getCalificacion());
			dtoLista.add(dto);
			
		}
	}catch(Exception e) {
		e.printStackTrace();
	}
	
	return dtoLista;
}

@Override
public CalificacionDto insertCalificacion(CalificacionDto calificacionDto) {
	Alumno alumno=new Alumno();
	Materia materia=new Materia();
	int pkIdAlumno=alumno.getPkId();
	int pkIdMateria=materia.getPkIdmateria();
	
	try {
		if (pkIdAlumno>0 && pkIdMateria>0){
			Calificacion calificacion = new Calificacion();
			calificacion.setPkId(calificacion.getPkId());
			calificacion.setPkIdmateria(calificacion.getPkIdmateria());
			calificacion.setCalificacion(calificacion.getCalificacion());
			calificacionRepository.save(calificacion);	
		}else {
			System.out.println("REVISA LOS DATOS DE ALUMNO Y MATERIA");
		}

	} catch (Exception e) {
		// TODO: handle exception
	}
	
	return calificacionDto ;
}
@Override
public CalificacionDto modificarCalificacion(CalificacionDto calificacionDto) {
	Alumno alumno=new Alumno();
	Materia materia=new Materia();
	int pkIdAlumno=alumno.getPkId();
	int pkIdMateria=materia.getPkIdmateria();
	
	try {
		if (pkIdAlumno>0 && pkIdMateria>0){
			Calificacion calificacion = new Calificacion();
			calificacion.setCalificacion(calificacion.getCalificacion());
			calificacionRepository.save(calificacion);	
		}else {
			System.out.println("REVISA LOS DATOS DE ALUMNO Y MATERIA");
		}

	} catch (Exception e) {
		// TODO: handle exception
	}
	
	return calificacionDto ;
}

@Override
public CalificacionDto deleteById(Integer pkId) {
	try {
		calificacionRepository.deleteById(pkId);
		
	} catch (Exception e) {
		// TODO: handle exception
	}
	return null;
}


}
