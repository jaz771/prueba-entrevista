package com.example.examn.modelo;

import java.io.Serializable;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the tipo_respuesto database table.
 * 
 */
@Entity
@Table(name="tipo_respuesto")
//@NamedQuery(name="TipoRespuesto.findAll", query="SELECT t FROM TipoRespuesto t")
public class Materia implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="pk_id_materia")
	private int pkIdmateria;

	private String materia;
	private float calificacion;

	
	public Materia() {
	}







	@Override
	public String toString() {
		return "Materia [pkIdmateria=" + pkIdmateria + ", materia=" + materia + ", calificacion=" + calificacion + "]";
	}







	public Materia(int pkIdmateria, String materia, float calificacion) {
		super();
		this.pkIdmateria = pkIdmateria;
		this.materia = materia;
		this.calificacion = calificacion;
	}


	public int getPkIdmateria() {
		return pkIdmateria;
	}


	public void setPkIdmateria(int pkIdmateria) {
		this.pkIdmateria = pkIdmateria;
	}


	public String getMateria() {
		return materia;
	}


	public void setMateria(String materia) {
		this.materia = materia;
	}


	public float getCalificacion() {
		return calificacion;
	}


	public void setCalificacion(float calificacion) {
		this.calificacion = calificacion;
	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}