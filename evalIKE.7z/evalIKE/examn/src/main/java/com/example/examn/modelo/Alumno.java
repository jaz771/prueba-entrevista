package com.example.examn.modelo;

import java.io.Serializable;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the respuesto database table.
 * 
 */
@Entity
//@NamedQuery(name="Alumno.findAll", query="SELECT r FROM Alumno r")
public class Alumno implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="pk_id")
	private int pkId;
	private String nombre;
	private String apellido_p;
	private String apellido_m;
	
	
	@ManyToOne
	@JoinColumn(name="fk_materia")
	private Materia materia;
	
	
	public Alumno() {
	}

	@Override
	public String toString() {
		return "Alumno [pkId=" + pkId + ", nombre=" + nombre + ", apellido_p=" + apellido_p + ", apellido_m="
				+ apellido_m + ", materia=" + materia + "]";
	}

	public Alumno(int pkId, String nombre, String apellido_p, String apellido_m, Materia materia) {
		super();
		this.pkId = pkId;
		this.nombre = nombre;
		this.apellido_p = apellido_p;
		this.apellido_m = apellido_m;
		this.materia = materia;
	}

	public int getPkId() {
		return pkId;
	}

	public void setPkId(int pkId) {
		this.pkId = pkId;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido_p() {
		return apellido_p;
	}

	public void setApellido_p(String apellido_p) {
		this.apellido_p = apellido_p;
	}

	public String getApellido_m() {
		return apellido_m;
	}

	public void setApellido_m(String apellido_m) {
		this.apellido_m = apellido_m;
	}

	public Materia getMateria() {
		return materia;
	}

	public void setMateria(Materia materia) {
		this.materia = materia;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}


	

	

}