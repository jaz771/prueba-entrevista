package com.example.examn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamnApplicationTests {

	@Test
	void contextLoads() {
	}

}
