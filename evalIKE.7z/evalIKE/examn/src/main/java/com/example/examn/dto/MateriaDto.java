package com.example.examn.dto;

import java.util.Date;

public class MateriaDto {

	private int pkId;
	private String pkIdmateria;
	private float calificacion;
	public int getPkId() {
		return pkId;
	}
	public void setPkId(int pkId) {
		this.pkId = pkId;
	}
	public String getPkIdmateria() {
		return pkIdmateria;
	}
	public void setPkIdmateria(String pkIdmateria) {
		this.pkIdmateria = pkIdmateria;
	}
	public float getCalificacion() {
		return calificacion;
	}
	public void setCalificacion(float calificacion) {
		this.calificacion = calificacion;
	}
	@Override
	public String toString() {
		return "MateriaDto [pkId=" + pkId + ", pkIdmateria=" + pkIdmateria + ", calificacion=" + calificacion + "]";
	}

	
	
	
}
